import pandas as pd

# Load the dataset
file_path = '/mnt/data/A_2017.11.30_16.48.26.csv'
data = pd.read_csv(file_path)

# Display the first few rows of the dataframe to understand its structure
data.head()
